#include "Arduino.h"
#include "Sos.h"

Sos::Sos(int pin){
pinMode(pin, OUTPUT);
_pin = pin;
}

void Sos::dot(){
digitalWrite(_pin, HIGH);
delay(250);
digitalWrite(_pin, LOW);
delay(250);
}

void Sos::dash(){
digitalWrite(_pin, HIGH);
delay(1000);
digitalWrite(_pin, LOW);
delay(250);
}


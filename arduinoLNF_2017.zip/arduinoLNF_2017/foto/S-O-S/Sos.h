#ifndef Sos_h
#define Sos_h

#include "Arduino.h"

class Sos{
   public:
      Sos(int pin);
      void dot();
      void dash();
   private:
      int _pin;
};
#endif

